import logging
from typing import Any, Literal, TypedDict,Optional

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ai_agent.llm import get_llm
from ai_agent.tools.compliance_tool import run_compliance_tool
from ai_agent.tools.edit_tool import run_edit_tool
from ai_agent.tools.history_tool import run_history_tool
from ai_agent.tools.log_tool import run_log_tool
from ai_agent.tools.suggest_tool import run_suggest_tool
#from backend.ai_agent import llm
from ai_agent import llm
from schemas.interaction_schema import StructuredFormData,IntentResult,ExtractionResult


logger = logging.getLogger(__name__)


class AgentState(TypedDict, total=False):
    #db: Session
    message: str
    session_id: str
    intent: Optional[str]
    extracted_data: Optional[dict[str, Any]]
    current_form_data: dict[str, Any]
    tool_result: dict[str, Any]
    response: Optional[dict[str, Any]]

def is_complete(data: dict) -> bool:
    try:
        return (
            data.get("hcp", {}).get("full_name") and
            data.get("interaction", {}).get("interaction_type")
        )
    except:
        return False

def _intent_node(state: AgentState) -> AgentState:
    llm = get_llm(temperature=0.0).with_structured_output(IntentResult)
    result = llm.invoke(f"""
You are an AI assistant for a medical CRM system.

Classify the user message into ONE of these intents:

1. log_interaction → user provides OR continues interaction details (meeting, sentiment, follow-up, clarification, etc.)
2. edit_interaction → user modifies existing data
3. suggest_follow_up → user explicitly asks what to do next
4. retrieve_history → user asks about past interaction
5. emotional_support → user expresses feelings (sad, hurt, stressed)
6. abusive → user uses insulting or offensive language
7. out_of_scope → ONLY if completely unrelated to CRM or medical interaction

IMPORTANT RULES:
- Follow-up questions (like "what should I clarify", "can you explain", "what next") are STILL log_interaction
- If the user is continuing the conversation, NEVER mark as out_of_scope
- Only mark out_of_scope if the message is clearly unrelated (like jokes, weather, random facts)
- If unsure → ALWAYS choose log_interaction

Message:
{state['message']}
""")
    return {"intent": result.intent}


def _route_from_intent(state: AgentState) -> str:
    intent = state.get("intent", "log_interaction")
    message = state.get("message", "").lower()
    if intent =="out_of_scope":
        return "out_of_scope"
    # ✅ ONLY allow history if explicitly asked
    if intent == "retrieve_history":
        if any(keyword in message for keyword in [
            "history",
            "previous",
            "past",
            "earlier"
        ]):
            return "retrieve_history"
        else:
            return "log_interaction"

    return intent

def generate_response(message: str, intent: str, data: dict) -> str:
    llm = get_llm()

    prompt = f"""
You are a CRM assistant.

Rules:
- Stay within medical/CRM context
- Be natural and helpful
- If emotional → be empathetic
- If abusive → respond calmly
- If out of scope → refuse politely
- Suggest next step if relevant

Context:
{data}

User:
{message}

Intent:
{intent}

Respond naturally in 2–4 lines.

Do NOT return JSON. Only return text.
"""

    try:
        result = llm.invoke(prompt)
        return result.content.strip()
    except Exception as e:
        if "rate_limit" in str(e):
            return "I'm a bit busy right now. Please try again in a few minutes."
    raise e

def _execute_tool_node(state: AgentState) -> AgentState:
    #db = state.get("db", None)
    #if db is None:
        #raise ValueError("Database connection not found.")
    llm = get_llm()
    message = state["message"]
    intent = state["intent"]
    current_form_data = dict(state.get("current_form_data", {})or {})
    extracted_data = state.get("extracted_data", {})

    if intent == "log_interaction":

        if not is_complete(extracted_data):

            prompt = f"""
    You are an AI CRM assistant.

    The user is trying to log an interaction, but the information is incomplete.

    Current known data:
    {state.get("current_form_data", {})}

    New input:
    "{state.get("message")}"

    Politely ask for ONLY the missing details required to complete the interaction.
    Do not repeat generic phrases. Be natural and conversational.
    Ask only for missing required info (hcp name or interaction type).
    Be natural.
    """

            try:
                llm_response = llm.invoke(prompt)
                response_text = llm_response.content
            except:
                llm_response = llm.invoke(prompt)
                response_text = llm_response.content

            return {
                "tool_result": {
                    "message": response_text,
                    "data": state.get("current_form_data", {}),
                    "metadata": {"status": "incomplete"}
                }
            }

    # 🚨 FIX 2: Complete → generate proper LLM response
        response_text = generate_response(
            state.get("message"),
            intent,
            state.get("current_form_data", {})
        )

        return {
            "tool_result": {
                "message": response_text,
                "data": state.get("current_form_data", {}),
                "metadata": {"status": "success"}
                }
            }
    elif intent == "edit_interaction":
        #interaction_id = current_form_data.get("interaction", {}).get("interaction_id")
        #if not interaction_id:
        response_text = generate_response(message, intent, current_form_data)
        tool_result = {
                "message": response_text,
                "data": current_form_data,
                "metadata": {"tool": "edit_tool (mocked)"},# "error": "missing_interaction_id"
            }
        #else:
            #tool_result = run_edit_tool( current_form_data, interaction_id)
    elif intent == "retrieve_history":
        #hcp_info = current_form_data.get("hcp", {})
        tool_result = {
        "message": f"Previous data: {current_form_data}",
        "data": current_form_data,
        "metadata": {"tool": "history_tool (mocked)"},
    }
    elif intent == "out_of_scope":
        response_text = generate_response(message, intent, current_form_data)
        tool_result = {
            "message": response_text,
            "data": current_form_data,
            "metadata": {"tool": "scope_guard"},
        }
    elif intent == "emotional_support":
        response_text = generate_response(message, intent, current_form_data)
        tool_result = {
            "message": response_text,
            "data": current_form_data,
            "metadata": {"tool": "support"},
        }

    elif intent == "abusive":
        response_text = generate_response(message, intent, current_form_data)
        tool_result = {
            "message": response_text,
            "data": current_form_data,
            "metadata": {"tool": "safety"},
        }
    else:
        sentiment = current_form_data.get("interaction", {}).get("sentiment")
        tool_result = run_suggest_tool(current_form_data, sentiment=sentiment)

    compliance_result = run_compliance_tool(message)
    compliance_flags = compliance_result["data"].get("compliance_flags", [])
    tool_result.setdefault("data", {}).setdefault("compliance_flags", compliance_flags)
    tool_result.setdefault("metadata", {})["intent"] = intent
    return {"tool_result": tool_result}


def build_agent():
    graph = StateGraph(AgentState)
    graph.add_node("intent_detection", _intent_node)
    graph.add_node("extraction", _extract_data_node)
    graph.add_node("merge_data", _merge_data_node)
    graph.add_node("tool_execution", _execute_tool_node)
    graph.add_node("response", _respond_node)
    graph.add_edge(START, "intent_detection")
    graph.add_edge("intent_detection", "extraction")
    graph.add_edge("extraction", "merge_data")
    
    graph.add_conditional_edges(
        "merge_data",
        _route_from_intent,
        {
            "log_interaction": "tool_execution",
            "edit_interaction": "tool_execution",
            "suggest_follow_up": "tool_execution",
            "retrieve_history": "tool_execution",
            "emotional_support": "tool_execution",
            "abusive": "tool_execution",
            "out_of_scope": "tool_execution",
        },
    )
    graph.add_edge("tool_execution", "response")
    graph.add_edge("response", END)

    logger.info("LangGraph agent initialized.")
    return graph.compile(checkpointer=MemorySaver())

def clean_data(data):
    cleaned = {}
    for k, v in data.items():
        if isinstance(v, dict):
            nested = clean_data(v)
            if nested:
                cleaned[k] = nested
        elif v not in [None, "", [], {}]:
            cleaned[k] = v
    return cleaned

def _extract_data_node(state: AgentState) -> AgentState:
    intent = state.get("intent")

    # Only extract for relevant intents
    if intent not in ["log_interaction", "edit_interaction"]:
        return {"extracted_data": {}}
    llm = get_llm(temperature=0.0).with_structured_output(ExtractionResult)
    prompt=f"""
    You are an AI assistant for a CRM system.
    
    Extract structured information from the user's message and return ONLY a valid JSON object.
    
    Expected JSON structure:
    {{
        "hcp": {{
            "full_name": string | null,
            "external_id": string | null}},
        "interaction": {{
            "interaction_type": string | null,
            "sentiment": string | null,
            "summary" : string | null}},
        "follow_up": {{
            "suggestion" : string |null,
            "due_days" : number | null}},
        "compliance_flags": string[] | null
    }}
    
    Rules:
    - Do NOT include any text outside JSON
    - If a field is not present, return null
    - Keep values concise and relevant

    User Message:
    {state['message']}
    """
    try:
        result = llm.invoke(prompt)
    except Exception as e:
        if "rate_limit" in str(e):
            return {"extracted_data": {}}
        raise 
    cleaned=clean_data(result.model_dump())
    return {"extracted_data": cleaned}

def is_valid_update(field: str, value: str) -> bool:
    llm = get_llm(temperature=0.0)

    prompt = f"""
You are validating CRM data.

Field: {field}
Value: {value}

Rules:
- Accept ONLY if value is clear, specific, and actionable
- Reject if vague, uncertain, or generic
- Respond ONLY with: YES or NO
"""

    try:
        result = llm.invoke(prompt).content.strip().upper()
        return result == "YES"
    except:
        return False



def _merge_data_node(state: AgentState) -> AgentState:
    current_form_data = state.get("current_form_data", {}) or {}
    extracted_data = state.get("extracted_data", {}) or {}
    llm=get_llm()
    # ✅ define first (IMPORTANT)
    def deep_merge(old: dict, new: dict):
        result = old.copy()

        for key, value in new.items():
            if isinstance(value, dict):
                result[key] = deep_merge(result.get(key, {}), value)

            elif value not in [None, "", [], {}]:

                # ✅ 1. Strict interaction type validation
                if key == "interaction_type":
                    valid_types = llm.invoke(f"""You are a CRM assistant. 
                                             Validate if the interaction type whether the interaction is possible in the user mentioned type, 
                                             if yes then return the interaction type mentioned in the user message otherwise, 
                                             Ask user to mention about the interaction_type """)
                    if valid_types.content.strip().lower() in ["yes", "no"]:
                        if valid_types.content.strip().lower() == "yes":
                            result[key] = value
                        else:
                            result[key] = llm.content()

                # ✅ 2. Summary → append, not overwrite
                if key == "summary":
                    old_summary = result.get(key, "") or ""
                    if isinstance(value, str):
                        if value.lower() not in old_summary.lower():
                            result[key] = (old_summary + " " + value).strip()
                    continue

                # ✅ 3. Prevent weaker overwrite
                existing_value = result.get(key)
                if (
                    isinstance(existing_value, str)
                    and isinstance(value, str)
                    and len(value.strip()) < len(existing_value.strip())
                ):
                    continue

                # ✅ 4. Basic sanity check
                if isinstance(value, str):
                    if len(value.strip()) < 3:
                        continue

                result[key] = value

        return result

    # ✅ TEMP merge for validation
    temp_data = deep_merge(current_form_data, extracted_data)

    # 🚨 FIX: check completeness on COMBINED DATA
    if not is_complete(temp_data):
        return {"current_form_data": current_form_data}

    # ✅ Only now commit
    return {"current_form_data": temp_data}

def _respond_node(state: AgentState) -> AgentState:
    tool_result = state.get("tool_result", {}) or {}
    current_form_data = state.get("current_form_data", {}) or {}
    final_data = {**current_form_data, **tool_result.get("data", {})}
    structured_data = StructuredFormData.model_validate(final_data)
    response={
        "action": "update_form",
        "data": structured_data.model_dump(),
        "message": tool_result.get("message", "Processed message."),
        "metadata": tool_result.get("metadata", {}),
    }
    return {"response": response}