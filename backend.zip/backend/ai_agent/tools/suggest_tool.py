from pydantic import BaseModel, Field

from ai_agent.llm import get_llm


class SuggestResult(BaseModel):
    suggestion: str
    due_days: int | None = Field(default=3)


def run_suggest_tool(user_message: str, sentiment: str | None = None) -> dict:
    llm = get_llm(temperature=0.2).with_structured_output(SuggestResult)
    result = llm.invoke(
        "Create a pharma-safe follow-up suggestion from this interaction.\n"
        f"Sentiment: {sentiment}\n"
        f"Interaction details: {user_message}"
    )
    return {
        "message": "Generated next-best follow-up.",
        "data": {
            "hcp": {},
            "interaction": {"sentiment": sentiment},
            "follow_up": result.model_dump(),
            "compliance_flags": [],
        },
        "metadata": {"tool": "suggest_tool"},
    }
