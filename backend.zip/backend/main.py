import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from config.settings import get_settings
from db.database import Base, engine
from models import hcp_model, interaction_model  # noqa: F401
from routes.chat import router as chat_router
from routes.interaction import router as interaction_router


settings = get_settings()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)

app = FastAPI(title=settings.app_name)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # for now allow all
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

#@app.on_event("startup")
#def on_startup() -> None:
#   Base.metadata.create_all(bind=engine)


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "env": settings.app_env}


app.include_router(chat_router, prefix=settings.api_prefix)
app.include_router(interaction_router, prefix=settings.api_prefix)
