import logging
from typing import Any
from unittest import result


from sqlalchemy.orm import Session

from ai_agent.agent import build_agent
from schemas.interaction_schema import ChatResponse, StructuredFormData


logger = logging.getLogger(__name__)
def deep_merge(old: dict, new: dict):
    result = old.copy()

    for key, value in new.items():
        if isinstance(value, dict):
            result[key] = deep_merge(result.get(key, {}), value)

        elif isinstance(value, list):
            # only overwrite if list has actual content
            if value:
                result[key] = value

        else:
            # ✅ ignore empty / null values
            if value is not None and str(value).strip() != "":
                result[key] = value

    return result

class AgentService:
    def __init__(self):
        self.graph = build_agent()
        self.session_form_cache: dict[str, dict[str, Any]] = {}

    def process_message(self, db: Session, session_id: str, message: str) -> ChatResponse:
        current_form_data = self.session_form_cache.get(
            session_id,
            {"hcp": {}, "interaction": {}, "follow_up": {}, "compliance_flags": []},
        )

        result = self.graph.invoke(
            { "message": message, "session_id": session_id, "current_form_data": current_form_data},
            config={"configurable": {"thread_id": session_id}},
        )
        response_data=result.get("response",{})
        new_data=response_data.get("data",{})
        final_data = deep_merge(current_form_data, new_data)
        structured_data = StructuredFormData.model_validate(final_data)
        self.session_form_cache[session_id] = structured_data.model_dump()

        
        response = ChatResponse(
            data=structured_data,
            message=response_data.get("message", "Processed message."),
            metadata=response_data.get("metadata", {}),
        )
        logger.info("Chat processed for session=%s action=%s", session_id, response.metadata.get("intent"))
        return response

    def reset_session(self, session_id: str):
        if session_id in self.session_form_cache:
            del self.session_form_cache[session_id]